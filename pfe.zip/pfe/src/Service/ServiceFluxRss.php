<?php
/**
 * Created by PhpStorm.
 * User: FANANE
 * Date: 14/04/2018
 * Time: 21:31
 */

namespace App\Service;
use Symfony\Component\DependencyInjection\ContainerInterface;

class ServiceFluxRss
{
    function __construct(ContainerInterface  $container)
    {
        $this->container = $container;
    }

    public function getPostListFromUrl($url){
        $post_list = array();
        try{
            $rss = simplexml_load_file($url);
            foreach ($rss->channel->item as $item){
                if ($this->checkParams($item)){
                    $datetime = date_create($item->pubDate);
                    $date = date_format($datetime, 'Y-m-d H:i:s');
                    array_push($post_list,array(
                        'title' => utf8_decode($item->title),
                        'link' => utf8_decode($item->link),
                        'date' => $date,
                        'description' => utf8_decode($item->description)
                    ));
                }

            }
        }catch (\Exception $e){
            $this->container->get('app.send.mailer')->sendMail('Backend Erreur', $e->getMessage());
        }
        return $post_list;
    }

    public function checkParams($item){
        if (isset($item->pubDate) && isset($item->title) && isset($item->link) && isset($item->description)){
            if ($item->pubDate && $item->title && $item->link && trim(utf8_decode($item->description))){
                return true;
            }
            return false;
        }else{
            return false;
        }
    }

}