<?php
/**
 * Created by PhpStorm.
 * User: FANANE
 * Date: 18/04/2018
 * Time: 22:12
 */

namespace App\Service;
use Symfony\Component\DependencyInjection\ContainerInterface;

class ServiceSendMailer
{
    function __construct(ContainerInterface  $container)
    {
        $this->container = $container;
    }

    public function sendMail(string $subject, string $body):bool {
        $message = (new \Swift_Message($subject))
           ->setFrom('mohamed.fanane.dev@gmail.com')
           ->setTo('mohamed.fanane.dev@gmail.com')
           ->setBody($body,
               'text/html'
           );

        return $this->container->get('mailer')->send($message) > 0;
   }
}