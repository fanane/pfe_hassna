<?php
/**
 * Created by PhpStorm.
 * User: FANANE
 * Date: 17/04/2018
 * Time: 21:15
 */

namespace App\Command;

use App\Entity\Categorie;
use App\Entity\Posts;
use App\Entity\FluxRss;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;

class SynchFluxRssCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            // the name of the command (the part after "bin/console")
            ->setName('synch:flux_rss')

            // the short description shown while running "php bin/console list"
            ->setDescription('Creates a new post from rss flux.')

            // the full command description shown when running the command with
            // the "--help" option
            ->setHelp('This command allows you to create a post...');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln([
            'Start date processing',
            date('Y-m-d H:i:s'),
        ]);

        /* Send mailer */
        $send_mailer = false;
        $number = 0;

        /* entityManager */
        $doctrine = $this->getContainer()->get('doctrine');
        $em = $doctrine->getEntityManager();

        /*  flux RSS */
        $FluxRss_urls = $em->getRepository('App\Entity\FluxRss')->findAll();

        /*  Categories */
        $categories = $em->getRepository('App\Entity\Categorie')->findAll();

        foreach ($FluxRss_urls as $FluxRss_url){
            $posts = $this->getContainer()->get('app.flux.rss')->getPostListFromUrl($FluxRss_url->getLink());
            foreach ($posts as $post){
                $flux = $em->getRepository('App\Entity\Posts')->findOneBy(['link' => $post['link']]);
                if (!$flux instanceof Posts){
                    $send_mailer = true;
                    $number += 1;
                    $article = new Posts();
                    /* Classement automatique */
                    $categorieIds = $this->getCategories($post['title'],$post['description'],$categories,$em);
                    foreach ($categorieIds as $cat_id){
                        $categorie = $em->getRepository('App\Entity\Categorie')->findOneById($cat_id);
                        $article->addCategory($categorie);
                    }


                    $article->setTitle($post['title']);
                    $article->setLink($post['link']);
                    $article->setDescription($post['description']);
                    $article->setDateCreate(new \DateTime());
                    $article->setPubDate(new \DateTime( $post['date']));
                    $em->persist($article);
                    $em->flush();
            }
        }
        }

        if ($send_mailer){
            $content = $this->getContainer()->get('templating')->render('mail/mis_a_jour.html.twig',
                array('number' => $number)
            );
            $this->getContainer()->get('app.send.mailer')->sendMail('Backend '.date('Y-m-d H:i'), $content);
        }
        $output->writeln([
            'finish date processing',
            date('Y-m-d H:i:s'),
        ]);
    }


    public function getCategories(string $title,string $desciption,$categories, $em): array{
        $categoryIds = array();
        $title = explode(' ',html_entity_decode(strip_tags($title)));
        $desciption = explode(' ',html_entity_decode(strip_tags($desciption)));

        foreach ($categories as $category){
            foreach ($category->getMotsCles() as $mots){
                if (in_array($mots, $title) || in_array($mots, $desciption)){
                    array_push($categoryIds,
                        array('id'=>$category->getId())
                        );
                }
            }
        }

        if (empty($categoryIds)){
            // Categorie Par Default
            $category = $em->getRepository('App\Entity\Categorie')->findOneById(4);
            return array('id'=>$category->getId());
        }
        return $this->unique_multidim_array($categoryIds,'id');
    }

    function unique_multidim_array(array $array,string $key) : array {
        $temp_array = array();
        $i = 0;
        $key_array = array();

        foreach($array as $val) {
            if (!in_array($val[$key], $key_array)) {
                $key_array[$i] = $val[$key];
                $temp_array[$i] = $val;
            }
            $i++;
        }
        return $temp_array;
    }
}