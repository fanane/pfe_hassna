<?php
/**
 * Created by PhpStorm.
 * User: FANANE
 * Date: 14/04/2018
 * Time: 21:09
 */

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{
    public function IndexAction(Request $request){
        return $this->redirectToRoute('admin');
    }
    public function GeneratePdfAction(Request $request){
       echo $request->query->get('id');
       die();
    }
}